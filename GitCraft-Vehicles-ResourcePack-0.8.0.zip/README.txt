GitCraft 0.8.0 resource pack for Minecraft Java 1.21.4.
61001 tractor; 61002 combine; 61003 plow; 61004 seeder; 61005 combine header.
Use with GitFarmingCore 0.8.0 and require-resource-pack=true.
