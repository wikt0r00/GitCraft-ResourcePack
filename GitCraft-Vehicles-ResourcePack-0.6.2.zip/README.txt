GitCraft Vehicles 0.6.2 — Minecraft Java 1.21.4
CustomModelData 61001 tractor, 61002 harvester.
Replace previous resource pack ZIP and update server.properties resource-pack URL.
All textures use solid colors to prevent striped UV artifacts.
Models are oversized; server item display size and collision remain controlled by plugin.
