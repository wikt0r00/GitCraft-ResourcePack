GitCraft Vehicles Resource Pack 0.6.0
Minecraft Java Edition 1.21.4

Models:
CARVED_PUMPKIN with CustomModelData 61001 = tractor
CARVED_PUMPKIN with CustomModelData 61002 = harvester

Installation: Minecraft -> Options -> Resource Packs -> Open Pack Folder -> paste this ZIP -> enable pack.
The current GitFarmingCore 0.6.0 plugin uses an invisible horse for movement and an ItemDisplay for the model.
These are original stylized voxel prototypes. They do NOT add wheel animations or realistic vehicle physics.
To enforce pack on server, upload ZIP to a direct HTTPS host and set server.properties resource-pack URL.
